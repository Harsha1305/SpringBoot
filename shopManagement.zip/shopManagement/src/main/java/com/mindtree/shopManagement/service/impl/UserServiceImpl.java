package com.mindtree.shopManagement.service.impl;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.session.SessionRegistry;
import org.springframework.stereotype.Service;

import com.mindtree.shopManagement.configuration.repo.UserRepository;
import com.mindtree.shopManagement.entity.ShopUser;
import com.mindtree.shopManagement.service.UserService;

@Service
public class UserServiceImpl implements UserService{

	@Autowired
	private UserRepository repository;
	
	@Autowired
	private SessionRegistry sessionRegistry;

	
	@Override
	public void saveUser(ShopUser user) {
		// TODO Auto-generated method stub
		repository.save(user);
		
	}


	@Override
	public List<ShopUser> displayUser() {
		// TODO Auto-generated method stub
		return repository.findAll();
	}


	@Override
	public ShopUser getUserByUserName(String username) {
		// TODO Auto-generated method stub
		return repository.findByUsername(username);
	}


	@Override
	public void updateUserDetails(ShopUser user) {
		// TODO Auto-generated method stub
		repository.save(user);
	}


	@Override
	public void deleteUser(int id) {
		// TODO Auto-generated method stub
		ShopUser user=repository.findById(id).get();
		repository.delete(user);
	}
	
	@Override
	public List<String> getUsersFromSessionRegistry() {
	    return sessionRegistry.getAllPrincipals().stream()
	      .filter(u -> !sessionRegistry.getAllSessions(u, false).isEmpty())
	      .map(Object::toString)
	      .collect(Collectors.toList());
	}

	@Override
	public ShopUser getUserById(int id) {
		// TODO Auto-generated method stub
		ShopUser user=repository.findById(id).get();
		return user;
	}


	@Override
	public List<ShopUser> displayUserByName(String username) {
		// TODO Auto-generated method stub
		List<ShopUser> list=repository.findAll();
		list=list.stream().filter(e->e.getUsername().equalsIgnoreCase(username)).collect(Collectors.toList());
		return list;
	}

}
