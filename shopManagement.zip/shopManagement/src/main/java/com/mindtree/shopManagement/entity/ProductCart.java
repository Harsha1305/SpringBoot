package com.mindtree.shopManagement.entity;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;

import org.springframework.format.annotation.DateTimeFormat;

@Entity
public class ProductCart {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int id;

	@DateTimeFormat(pattern = "yyyy-MM-dd")
	private Date date;

	@ManyToOne
	private Product products;

	@ManyToOne
	private ShopUser user;

	public ProductCart() {
		super();
		// TODO Auto-generated constructor stub
	}

	
	public ProductCart(Date date, Product products, ShopUser user) {
		super();
		this.date = date;
		this.products = products;
		this.user = user;
	}


	public ProductCart(int id, Date date, Product products, ShopUser user) {
		super();
		this.id = id;
		this.date = date;
		this.products = products;
		this.user = user;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public Date getDate() {
		return date;
	}

	public void setDate(Date date) {
		this.date = date;
	}

	public Product getProducts() {
		return products;
	}

	public void setProducts(Product products) {
		this.products = products;
	}

	public ShopUser getUser() {
		return user;
	}

	public void setUser(ShopUser user) {
		this.user = user;
	}


	@Override
	public String toString() {
		return "ProductCart [id=" + id + ", date=" + date + ", products=" + products + ", user=" + user + "]";
	}

	
}
