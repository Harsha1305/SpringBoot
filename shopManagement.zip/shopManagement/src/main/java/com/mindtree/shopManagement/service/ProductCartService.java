package com.mindtree.shopManagement.service;

import java.util.Date;
import java.util.List;

import com.mindtree.shopManagement.entity.ProductCart;

public interface ProductCartService {

	public void insertToProductCart(ProductCart productCart);
	
	public List<ProductCart> displayProductCart();

	public List<ProductCart> filterProductCart(String name, Date date);

}
