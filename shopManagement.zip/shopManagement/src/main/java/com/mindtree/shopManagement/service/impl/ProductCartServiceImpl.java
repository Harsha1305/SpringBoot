package com.mindtree.shopManagement.service.impl;


import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mindtree.shopManagement.configuration.repo.ProductCartRepository;
import com.mindtree.shopManagement.entity.ProductCart;
import com.mindtree.shopManagement.service.ProductCartService;

@Service
public class ProductCartServiceImpl implements ProductCartService{

	
	@Autowired
	private ProductCartRepository repository;

	@Override
	public void insertToProductCart(ProductCart productCart) {
		// TODO Auto-generated method stub
		repository.save(productCart);
	}

	@Override
	public List<ProductCart> displayProductCart() {
		// TODO Auto-generated method stub
		List<ProductCart> list= repository.findAll();
		return list;
	}

	@Override
	public List<ProductCart> filterProductCart(String name, Date date) {
		// TODO Auto-generated method stub
		List<ProductCart> productCart=repository.findAll();
		productCart=productCart.stream().filter(e->e.getProducts().getName().equals(name)).collect(Collectors.toList());
		
		return productCart.stream().filter(e->e.getDate().compareTo(date)==0).collect(Collectors.toList()); 
	}

	
	
	
}
