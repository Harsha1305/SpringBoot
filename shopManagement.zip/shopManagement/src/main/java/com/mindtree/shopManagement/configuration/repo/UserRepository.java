package com.mindtree.shopManagement.configuration.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.mindtree.shopManagement.entity.ShopUser;

public interface UserRepository extends JpaRepository<ShopUser, Integer>{
	public ShopUser findByUsername(String username);

}
