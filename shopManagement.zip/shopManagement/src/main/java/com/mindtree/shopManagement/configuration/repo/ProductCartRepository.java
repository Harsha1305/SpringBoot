package com.mindtree.shopManagement.configuration.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.mindtree.shopManagement.entity.ProductCart;

public interface ProductCartRepository extends JpaRepository<ProductCart, Integer>{

}
