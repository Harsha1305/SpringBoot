package com.mindtree.shopManagement.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mindtree.shopManagement.configuration.repo.ProductRepo;
import com.mindtree.shopManagement.entity.Product;
import com.mindtree.shopManagement.service.ProductService;

@Service
public class ProductServiceImpl implements ProductService{

	@Autowired
	private ProductRepo productRepo;
	
	@Override
	public void insertProduct(Product product) {
		// TODO Auto-generated method stub
		productRepo.save(product);
		
	}

	@Override
	public List<Product> displayProduct() {
		// TODO Auto-generated method stub
		return productRepo.findAll();
	}

	@Override
	public Product getProductById(int id) {
		// TODO Auto-generated method stub
		return productRepo.findById(id).get();
	}

	@Override
	public void updateProduct(Product product) {
		// TODO Auto-generated method stub
		productRepo.save(product);
	}

	@Override
	public void deleteProduct(int id) {
		// TODO Auto-generated method stub
		Product product =productRepo.findById(id).get();
		productRepo.delete(product);
	}


}
