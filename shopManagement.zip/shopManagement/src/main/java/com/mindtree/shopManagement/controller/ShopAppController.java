package com.mindtree.shopManagement.controller;

import java.security.Principal;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import com.mindtree.shopManagement.entity.Product;
import com.mindtree.shopManagement.entity.ProductCart;
import com.mindtree.shopManagement.entity.ShopUser;
import com.mindtree.shopManagement.service.ProductCartService;
import com.mindtree.shopManagement.service.ProductService;
import com.mindtree.shopManagement.service.UserService;

@Controller
public class ShopAppController {

	@Autowired
	private BCryptPasswordEncoder bcryptEncoder;

	@Autowired
	private UserService userService;

	@GetMapping("/")
	public String home() {
		return "index.jsp";
	}

	@GetMapping("/login")
	public String login() {
		return "login.jsp";
	}

	@GetMapping("/logout-success")
	public String logout() {
		return "logout.jsp";
	}

	@GetMapping("/register")
	public String register() {
		return "register.jsp";
	}

	@GetMapping("/adminHome")
	public String adminHome() {
		return "admin.jsp";
	}

	@PostMapping("/insertUserDetails")
	public String saveDetails(ShopUser user) {
		user.setPassword(bcryptEncoder.encode(user.getPassword()));
		System.out.println(user);
		userService.saveUser(user);
		return "login.jsp";
	}

	@GetMapping("/userHome")
	public String userHome() {
		return "user.jsp";
	}

//--------------------------------------------------------------------------------------------------------//
	@Autowired
	ProductService productService;

	@GetMapping("/product")
	public String productHome() {
		return "product.jsp";
	}

	@GetMapping("/insertProduct")
	public String create() {
		return "productInsert.jsp";
	}

	@PostMapping("/insertProducts")
	public String insertProduct(Product product) {
		productService.insertProduct(product);
		return "product.jsp";
	}

	@GetMapping("/displayproduct")
	public String displayProducts(Model model) {

		model.addAttribute("products", productService.displayProduct());
		return "productList.jsp";
	}

	@GetMapping("/updateProduct")
	public String updateProduc() {

		return "productUpdate.jsp";
	}

	@GetMapping("/updateProductById")
	public ModelAndView updateProducts(@RequestParam int id, Model model) {
		ModelAndView mv = new ModelAndView("productUpdate.jsp");
		Product product = productService.getProductById(id);
		// model.addAttribute("employee",employee);
		mv.addObject(product);

		return mv;
	}

	@PostMapping("/updateProductid")
	public String updateProduct(Product product) {
		productService.updateProduct(product);
		return "product.jsp";
	}

	@GetMapping("/deleteProducts")
	public String getDeleteProduct() {

		return "productDelete.jsp";
	}

	@PostMapping("/deleteProduct")
	public String delete(@RequestParam int id) {
		productService.deleteProduct(id);
		return "product.jsp";
	}

	// ---------------------------------------------------------------------------------------------------//

	@GetMapping("/userAdmin")
	public String usertHome() {
		return "userAdmin.jsp";
	}

	@GetMapping("/displayUser")
	public String displayUser(Model model) {

		model.addAttribute("users", userService.displayUser());
		return "userList.jsp";
	}

	@GetMapping("/updateUser")
	public String updateUserr() {

		return "userUpdate.jsp";
	}

	@GetMapping("/updateUserByName")
	public ModelAndView updateUsers(@RequestParam String username, Model model) {
		ModelAndView mv = new ModelAndView("userUpdate.jsp");
		ShopUser user = userService.getUserByUserName(username);
		mv.addObject(user);

		return mv;
	}

	@PostMapping("/updateUserid")
	public String updateUser(ShopUser user) {
		user.setPassword(bcryptEncoder.encode(user.getPassword()));
		System.out.println(user);
		userService.updateUserDetails(user);
		return "product.jsp";
	}

	@GetMapping("/deleteUser")
	public String getDeleteUser() {

		return "userDelete.jsp";
	}

	@PostMapping("/deleteUsers")
	public String deleteUsers(@RequestParam int id) {
		userService.deleteUser(id);
		return "userAdmin.jsp";
	}

	@RequestMapping("/listOfLoggedInUsers")
	public String listOfLogedInUsers(Model model) {
		List<String> list = userService.getUsersFromSessionRegistry();
		model.addAttribute("lists", list);
		return "trackLogedInUsers.jsp";
	}

	@GetMapping("/displayUserByName")
	public String displayUserByName(@RequestParam String username, Model model) {
		List<ShopUser> list = userService.displayUserByName(username);
		if (list.size() != 0) {
			model.addAttribute("users", list);
		} else {
			model.addAttribute("message", "User not found Please check your details");
		}

		return "userListByName.jsp";
	}

	// ---------------------------------------------------------------------------------------------------------------//

	@Autowired
	ProductCartService productCartService;

	@RequestMapping("/userProduct")
	public String userhome(Principal principal, Model model) {
		String name = principal.getName();
		ShopUser user = userService.getUserByUserName(name);
		List<Product> products = productService.displayProduct();
		model.addAttribute("name", name);
		model.addAttribute("user", user);
		model.addAttribute("products", products);
		return "productCart.jsp";
	}

	@RequestMapping("/buyProduct")
	public String Update(@RequestParam("id") int id, @RequestParam("pid") int pid, Model model) {
		Product product = productService.getProductById(pid);
		ShopUser user = userService.getUserById(id);
		model.addAttribute("product", product);
		model.addAttribute("user", user);
		return "buy.jsp";
	}

	@RequestMapping("/buy")
	public String buy(ProductCart productCart) {

		productCartService.insertToProductCart(productCart);
		return "buy.jsp";
	}

	@GetMapping("/displayProductCart")
	public String displayProductCart(Model model) {

		model.addAttribute("productCart", productCartService.displayProductCart());
		return "buyProductDetails.jsp";
	}

	@GetMapping("/filterByProductsDate")
	public String filterProductCart(@RequestParam String name,
			@RequestParam(name = "date", defaultValue = "1900-01-01") @DateTimeFormat(pattern = "yyyy-MM-dd") Date date,
			Model model) {
		List<ProductCart> list = productCartService.filterProductCart(name, date);
		if (list.size() != 0) {
			model.addAttribute("productCart", list);
		} else {
			model.addAttribute("message", "Products not found Please check your details");
		}

		return "filterProducts.jsp";
	}

}
