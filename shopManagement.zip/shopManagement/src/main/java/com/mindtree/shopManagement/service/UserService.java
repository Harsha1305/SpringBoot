package com.mindtree.shopManagement.service;

import java.util.List;
import com.mindtree.shopManagement.entity.ShopUser;

public interface UserService {

	public void saveUser(ShopUser user);

	public List<ShopUser> displayUser();

	public ShopUser getUserByUserName(String username);

	public void updateUserDetails(ShopUser user);

	public void deleteUser(int id);

	public List<String> getUsersFromSessionRegistry();

	public ShopUser getUserById(int id);

	public List<ShopUser> displayUserByName(String username);
	
	

}
