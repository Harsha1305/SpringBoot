package com.mindtree.service.impl;

import java.util.Set;
import java.util.stream.Collectors;

import com.mindtree.entity.Employee;
import com.mindtree.service.EmployeeService;

public class EmployeeServiceImpl implements EmployeeService {

	@Override
	public Set<Employee> sortEmployee(String location, Set<Employee> employees) {
		// TODO Auto-generated method stub
		return employees.stream().filter(e -> e.getLocation().equalsIgnoreCase(location)).collect(Collectors.toSet());
	}

	@Override
	public double calcaulateIncome(Set<Employee> employees) {
		// TODO Auto-generated method stub
		double totalIncome = employees.stream().map(e -> e.getSalary()).reduce(0.0, (total, sal) -> total + sal);
		return totalIncome;
	}

}
