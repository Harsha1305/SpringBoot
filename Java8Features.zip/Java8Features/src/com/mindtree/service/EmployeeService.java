package com.mindtree.service;


import java.util.List;
import java.util.Set;

import com.mindtree.entity.Employee;

public interface EmployeeService {

	@FunctionalInterface
	public interface EmployeeServe {
		void display(Set<Employee> employee);
	}

	static Employee getEmployeeById(byte id, Set<Employee> employees) {
		
		for(Employee employee:employees)
		{
			if(employee.getId()==id)
			{
				return employee;
			}
		}
		return null;
		
	}

	default Employee updateEmployee(byte id, Set<Employee> employees,double salary) {
		for(Employee employee:employees)
		{
			if(employee.getId()==id)
			{
				employee.setSalary(salary);
				return employee;
			}
		}
		return null;
	}
	
	public Set<Employee> sortEmployee(String location,Set<Employee> employees);
	
	public double calcaulateIncome(Set<Employee> employees);

}
