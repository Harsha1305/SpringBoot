package com.mindtree.app;

import java.util.LinkedHashSet;
import java.util.Scanner;
import java.util.Set;

import com.mindtree.entity.Employee;
import com.mindtree.service.EmployeeService;
import com.mindtree.service.EmployeeService.EmployeeServe;
import com.mindtree.service.impl.EmployeeServiceImpl;

public class EmployeeManagement {

	private static Scanner scanner = new Scanner(System.in);
	private static Set<Employee> employees = new LinkedHashSet<>();
	private static EmployeeService employeeService = new EmployeeServiceImpl();

	public static void main(String[] args) {
		byte choice = 0;
		do {
			System.out.println("Enter the below choices");
			System.out.println("1. Insert employee details");
			System.out.println("2. Update employee details");
			System.out.println("3. display employee details by id");
			System.out.println("4. sort employee details based on location");
			System.out.println("5. display name and annual salary of an employee");
			choice = scanner.nextByte();
			menu(choice);
		} while (choice < 6);
	}

	private static Set<Employee> insertEmployee() {
		System.out.println("Enter how many employee details you want to insert");
		byte num = scanner.nextByte();
		for (int i = 0; i < num; i++) {
			System.out.println("Enter the employee id");
			byte id = scanner.nextByte();
			System.out.println("Enter the employee name");
			String name = scanner.next();
			System.out.println("Enter the salary of the employee");
			double salary = scanner.nextDouble();
			System.out.println("Enter the location of employee where he/she works");
			String location = scanner.next();
			employees.add(new Employee(id, name, salary, location));

		}

		return employees;
	}

	private static void menu(byte choice) {
		// TODO Auto-generated method stub
		switch (choice) {
		case 1:
			Set<Employee> set = insertEmployee();
			displayEmployeeDetails(set);
			System.out.println("-------------------------------------------------------");
			break;
		case 2:
			System.out.println("Enter the employee id");
			byte id = scanner.nextByte();
			System.out.println("Enter the salary which you want to update");
			double salary = scanner.nextDouble();
			Employee employee = employeeService.updateEmployee(id, employees, salary);
			displayEmployee(employee);
			System.out.println("-------------------------------------------------------");
			break;
		case 3:
			System.out.println("Enter the employee id");
			id = scanner.nextByte();
			employee = EmployeeService.getEmployeeById(id, employees);
			displayEmployee(employee);
			System.out.println("-------------------------------------------------------");
			break;
		case 4:
			System.out.println("Enter the location on which you want to sort");
			String location = scanner.next();
			set = employeeService.sortEmployee(location, employees);
			displayEmployeeDetails(set);
			System.out.println("-------------------------------------------------------");
			break;
		case 5:
			salary = employeeService.calcaulateIncome(employees);
			System.out.println("The total amount which is to be paid for employees");
			System.out.println(salary);
			System.out.println("-------------------------------------------------------");
			break;
		default:
			System.out.println("Enter the correct options");

		}
	}

	private static void displayEmployee(Employee employee) {
		// TODO Auto-generated method stub
		System.out.println((employee.getId() + " : " + employee.getName() + " : " + employee.getSalary() + " : "
				+ employee.getLocation()));
	}

	private static void displayEmployeeDetails(Set<Employee> set) {
		// TODO Auto-generated method stub
		EmployeeServe service = (emp) -> {
			emp.forEach(e -> System.out
					.println(e.getId() + " : " + e.getName() + " : " + e.getSalary() + " : " + e.getLocation()));
		};
		service.display(set);
	}
}
