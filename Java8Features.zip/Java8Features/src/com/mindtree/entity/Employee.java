package com.mindtree.entity;

public class Employee implements Comparable<Employee>{
	private byte id;
	private String name;
	private double salary;
	private String location;

	public Employee() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Employee(byte id, String name, double salary, String location) {
		super();
		this.id = id;
		this.name = name;
		this.salary = salary;
		this.location = location;
	}

	public byte getId() {
		return id;
	}

	public void setId(byte id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public double getSalary() {
		return salary;
	}

	public void setSalary(double salary) {
		this.salary = salary;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + id;
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Employee other = (Employee) obj;
		if (id != other.id)
			return false;
		return true;
	}

	@Override
	public int compareTo(Employee employee) {
		// TODO Auto-generated method stub
		return this.getLocation().compareTo(employee.getLocation());
		
	}
	
	
	
	
}
