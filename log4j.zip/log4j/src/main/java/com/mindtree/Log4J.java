package com.mindtree;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@SpringBootApplication
@RestController
public class Log4J
{
	private static final Logger logger = LoggerFactory.getLogger(Log4J.class);

	public static void main(String[] args)
	{
		SpringApplication.run(Log4J.class, args);
		logger.debug("This is a debug message");
		logger.info("This is a info message");
		logger.warn("This is a warn message");
		logger.error("This is a error message");
	}

	@GetMapping("/hello")
	public String helloWorld()
	{
		logger.info("Inside helloWorld method---");
		return "Hello World , Peter ";
	}

}
