package com.mindtree.genieManagement.service;

import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assumptions.assumeTrue;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;
import org.junit.jupiter.api.MethodOrderer.OrderAnnotation;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.Spy;
import org.modelmapper.ModelMapper;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import com.mindtree.genieManagement.dto.CampusMindDto;
import com.mindtree.genieManagement.dto.GenieDto;
import com.mindtree.genieManagement.entity.CampusMind;
import com.mindtree.genieManagement.entity.Genie;
import com.mindtree.genieManagement.exception.CampusMIDNotFoundException;
import com.mindtree.genieManagement.exception.GenieIDNotFoundException;
import com.mindtree.genieManagement.exception.ServiecException;
import com.mindtree.genieManagement.repository.CampusMindRepository;
import com.mindtree.genieManagement.repository.GenieRepository;
import com.mindtree.genieManagement.service.impl.GenieManagementServiceImpl;



@SpringBootTest
@TestMethodOrder(OrderAnnotation.class)
public class GenieManagementServiceTest {
	
	@InjectMocks
	@Spy
	GenieManagementServiceImpl genieServiceImpl;
	
	@Mock
	CampusMindRepository campusMindRepository;
	
	
	@Mock
	GenieRepository genieRepository;
	
	@Mock
	ModelMapper modelMapper = new ModelMapper();

	CampusMind campusMind = new CampusMind("m106691", "harsha", "java", null);
	Optional<CampusMind> campusMind1 = Optional.empty();
	CampusMindDto campusMindDto = new CampusMindDto("m106691", "harsha", "java", null);
	
	Genie genie = new Genie(1, "laptop issue", true, campusMind);
	Optional<Genie> genie1=Optional.empty();
	List<GenieDto> list=new ArrayList<GenieDto>();
	List<Genie> list1=new ArrayList<Genie>();
	GenieDto genieDto=new GenieDto(1, "laptop issue", true, campusMindDto);
	
	
	
	Genie updateGenie = new Genie(1, "laptop issue", false, campusMind);
	GenieDto updateGenieDto=new GenieDto(1, "laptop issue", false, campusMindDto);
	

	
	@Test
	@Order(1)
	public void convertDtoToEntityTest() {

		when(modelMapper.map(campusMindDto, CampusMind.class)).thenReturn(campusMind);
		assertEquals(genieServiceImpl.campusMindDtoToCampusMind(campusMindDto), campusMind);

	}

	@Test
	@Order(2)
	public void convertEntityToDtoTest() {

		when(modelMapper.map(campusMind, CampusMindDto.class)).thenReturn(campusMindDto);
		assertEquals(genieServiceImpl.campusMindToCampusMindDto(campusMind), campusMindDto);

	}
	@Test
	@Order(3)
	public void convertGenieDtoToEntityTest() {

		when(modelMapper.map(genieDto, Genie.class)).thenReturn(genie);
		assertEquals(genieServiceImpl.genieDtoToGenie(genieDto), genie);

	}

	@Test
	@Order(4)
	public void convertGenieEntityToDtoTest() {

		when(modelMapper.map(genie, GenieDto.class)).thenReturn(genieDto);
		assertEquals(genieServiceImpl.genieToGenieDto(genie), genieDto);

	}
	
	@Test
	@Order(5)
	public void insertMindsTest() {
		Mockito.doReturn(campusMind).when(genieServiceImpl).campusMindDtoToCampusMind(campusMindDto);
		Mockito.doReturn(campusMindDto).when(genieServiceImpl).campusMindToCampusMindDto(campusMind);
		when(campusMindRepository.save(campusMind)).thenReturn(campusMind);
		assertEquals(genieServiceImpl.insertCampus(campusMindDto), campusMindDto);
	}
	
	
	@Test
	@Order(6)
	public void raiseGenie() throws ServiecException {
		Mockito.doReturn(genie).when(genieServiceImpl).genieDtoToGenie(genieDto);
		Mockito.doReturn(genieDto).when(genieServiceImpl).genieToGenieDto(genie);
		when(campusMindRepository.findByMid(campusMind.getMid())).thenReturn((campusMind));
		when(genieRepository.save(genie)).thenReturn(genie);
		assertEquals(genieServiceImpl.insertGenie(genieDto,campusMind.getMid()), genieDto);
	}
	
	@Test
	@Order(7)
	public void displayTest() throws ServiecException
	{
		list.add(genieDto);
		list1.add(genie);
		Mockito.doReturn(genieDto).when(genieServiceImpl).genieToGenieDto(genie);
		when(genieRepository.findByStatus(true)).thenReturn(list1);
		assertEquals(genieServiceImpl.displayGenieDetails(true), list);
	
	}
	
	@Test
	@Order(8)
	public void updateStatusTest() throws ServiecException
	{
		Mockito.doReturn(genieDto).when(genieServiceImpl).genieToGenieDto(genie);
		when(genieRepository.findById(genie.getGenieId())).thenReturn(Optional.of(genie));
		when(genieRepository.save(genie)).thenReturn(genie);
		assertEquals(genieServiceImpl.updateGenieStatus( genie.isGenieStatus(),genie.getGenieId()), genieDto);
	}
	
	@Test
	@Order(9)
	public void genieIdInvalidTest()  throws ServiecException
	{
		assumeTrue(!genie1.isPresent());
		assertThatThrownBy(()->genieServiceImpl.updateGenieStatus(genie.isGenieStatus(),genie.getGenieId())).isInstanceOf(GenieIDNotFoundException.class);
	}
	
	
	



	

}
