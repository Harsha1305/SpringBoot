package com.mindtree.genieManagement.contoller;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpStatus;

import com.mindtree.genieManagement.controller.GenieManagementController;
import com.mindtree.genieManagement.dto.CampusMindDto;
import com.mindtree.genieManagement.dto.GenieDto;
import com.mindtree.genieManagement.entity.CampusMind;
import com.mindtree.genieManagement.exception.ControllerException;
import com.mindtree.genieManagement.exception.GenieIDNotFoundException;
import com.mindtree.genieManagement.service.GenieManagementService;



@SpringBootTest
public class GenieManagementControllerTest {
	@InjectMocks
	GenieManagementController genieController;
	
	
	@Mock
	GenieManagementService genieservice;
	
	
	
   // Genie genie=new Genie(1, "ide installation problem", false,null );
	List<GenieDto> list=new ArrayList<GenieDto>();
	CampusMindDto campusMindDto=new CampusMindDto("m106691", "harsha", "java", null);
	CampusMind campusMind=new CampusMind("m106691", "harsha", "java", null);
	GenieDto genieDto=new GenieDto("laptop problem", false, null);
	
	
	
	
	
	@Test
	public void insertMindsTest()
	{
		when(genieservice.insertCampus(campusMindDto)).thenReturn(campusMindDto);
		assertEquals(genieController.insertCampus(campusMindDto).getStatusCode(),HttpStatus.CREATED);
	}
	
	
	@Test
	public void insertGenieToCampusMindTest() throws ControllerException
	{
		when(genieservice.insertGenie(genieDto,campusMind.getMid())).thenReturn(genieDto);
		assertEquals(genieController.insertGenie(genieDto,campusMind.getMid()).getStatusCode(),HttpStatus.CREATED);
	}
	
	
	@Test
	public void displayGenieTest() throws ControllerException 
	{
		boolean status=true;
		
	    when(genieservice.displayGenieDetails(status)).thenReturn(list);
		assertEquals(genieController.displayGenieDetails(status).getStatusCode(),HttpStatus.FOUND);
	}
	
	
	@Test
	public void changeStatusTest()  throws ControllerException 
	{
	    when(genieservice.updateGenieStatus(true,genieDto.getId())).thenReturn(genieDto);
		assertEquals(genieController.updateGenieStatus(true,genieDto.getId()).getStatusCode(),HttpStatus.OK);
	}

}
