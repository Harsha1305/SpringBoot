package com.mindtree.genieManagement;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GenieManagementApplicationTests {

	@Test
	void contextLoads() {
	}

}
