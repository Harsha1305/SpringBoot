package com.mindtree.genieManagement.service;

import java.util.List;

import com.mindtree.genieManagement.dto.CampusMindDto;
import com.mindtree.genieManagement.dto.GenieDto;
import com.mindtree.genieManagement.exception.CampusMIDNotFoundException;
import com.mindtree.genieManagement.exception.GenieIDNotFoundException;
import com.mindtree.genieManagement.exception.ServiecException;

public interface GenieManagementService {

	public List<GenieDto> displayGenieDetails(boolean status) throws GenieIDNotFoundException;

	public CampusMindDto insertCampus(CampusMindDto campusDto);

	public GenieDto insertGenie(GenieDto genieDto, String mid) throws CampusMIDNotFoundException;

	public GenieDto updateGenieStatus(boolean status, int id) throws ServiecException;

//	public GenieDto getByGenieId(int id) throws  ServiecException;
	

}
