package com.mindtree.genieManagement.exception;

public class GenieIDNotFoundException extends ServiecException {

	public GenieIDNotFoundException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public GenieIDNotFoundException(String message, Throwable cause, boolean enableSuppression,
			boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		// TODO Auto-generated constructor stub
	}

	public GenieIDNotFoundException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public GenieIDNotFoundException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public GenieIDNotFoundException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

}
