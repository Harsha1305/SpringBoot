package com.mindtree.genieManagement.dto;

import java.util.Set;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

public class CampusMindDto {
	private String mid;
	private String name;
	private String projectName;
	@JsonIgnoreProperties(value = "campusMind")
	private Set<GenieDto> genies;

	public CampusMindDto() {
		super();
		// TODO Auto-generated constructor stub
	}

	public CampusMindDto(String mid, String name, String projectName, Set<GenieDto> genies) {
		super();
		this.mid = mid;
		this.name = name;
		this.projectName = projectName;
		this.genies = genies;
	}

	public String getMid() {
		return mid;
	}

	public void setMid(String mid) {
		this.mid = mid;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getProjectName() {
		return projectName;
	}

	public void setProjectName(String projectName) {
		this.projectName = projectName;
	}

	public Set<GenieDto> getGenies() {
		return genies;
	}

	public void setGenies(Set<GenieDto> genies) {
		this.genies = genies;
	}

}