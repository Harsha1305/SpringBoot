package com.mindtree.genieManagement.service.impl;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

//import com.mindtree.cafeManagement.dto.CafeDto;
//import com.mindtree.cafeManagement.entity.Cafe;
import com.mindtree.genieManagement.dto.CampusMindDto;
import com.mindtree.genieManagement.dto.GenieDto;
import com.mindtree.genieManagement.entity.CampusMind;
import com.mindtree.genieManagement.entity.Genie;
import com.mindtree.genieManagement.exception.CampusMIDNotFoundException;
import com.mindtree.genieManagement.exception.GenieIDNotFoundException;
import com.mindtree.genieManagement.exception.ServiecException;
import com.mindtree.genieManagement.repository.CampusMindRepository;
import com.mindtree.genieManagement.repository.GenieRepository;
import com.mindtree.genieManagement.service.GenieManagementService;

@Service
public class GenieManagementServiceImpl implements GenieManagementService {

	ModelMapper modelMapper = new ModelMapper();

	@Autowired
	private GenieRepository genieRepository;

	@Autowired
	private CampusMindRepository campusRepository;

	public CampusMind campusMindDtoToCampusMind(CampusMindDto campusMinddto) {
		return modelMapper.map(campusMinddto, CampusMind.class);
	}

	public CampusMindDto campusMindToCampusMindDto(CampusMind campusMind) {
		return modelMapper.map(campusMind, CampusMindDto.class);
	}

	public Genie genieDtoToGenie(GenieDto geniedto) {
		return modelMapper.map(geniedto, Genie.class);
	}

	public GenieDto genieToGenieDto(Genie genie) {
		return modelMapper.map(genie, GenieDto.class);
	}

	@Override
	public GenieDto updateGenieStatus(boolean status, int id) throws ServiecException {
		// TODO Auto-generated method stub
		Optional<Genie> genie = genieRepository.findById(id);
		
		
		if(genie.isPresent())
		{
		Genie genie1=genie.get();
		genie1.setGenieStatus(status);
		genie1 = genieRepository.save(genie1);
		GenieDto genieDto = genieToGenieDto(genie1);
		return genieDto;
		}
		else
		{
			throw new GenieIDNotFoundException("invalid genie id");
		}
	}

	@Override
	public List<GenieDto> displayGenieDetails(boolean status) throws GenieIDNotFoundException {
		// TODO Auto-generated method stub
		List<Genie> genie = genieRepository.findByStatus(status);
		if (genie.size() != 0) {
			return genie.stream().map(this::genieToGenieDto).collect(Collectors.toList());
		} else {
			throw new GenieIDNotFoundException("No Data Found");
		}

	}

	@Override
	public CampusMindDto insertCampus(CampusMindDto campusDto) {
		// TODO Auto-generated method stub
		CampusMind campusMind = campusMindDtoToCampusMind(campusDto);
		campusMind = campusRepository.save(campusMind);
		campusDto = campusMindToCampusMindDto(campusMind);
		return campusDto;
	}

	@Override
	public GenieDto insertGenie(GenieDto genieDto, String mid) throws CampusMIDNotFoundException {
//		// TODO Auto-generated method stub

		CampusMind campusMind = campusRepository.findByMid(mid);
		Genie genie = genieDtoToGenie(genieDto);
		if (campusMind != null) {
			genie.setCampusMind(campusMind);
			System.out.println(campusMind.getName());
			genie = genieRepository.save(genie);
			genieDto = genieToGenieDto(genie);
			return genieDto;
		} else {
			throw new CampusMIDNotFoundException("Campus Id Not Found Exception");
		}

	}

//	@Override
//	public GenieDto getByGenieId(int id) throws ServiecException {
//		// TODO Auto-generated method stub
//		Genie genie = genieRepository.findById(id)
//				.orElseThrow(() -> new GenieIDNotFoundException("Genie id not found exception"));
//		return genieToGenieDto(genie);
//	}

}
