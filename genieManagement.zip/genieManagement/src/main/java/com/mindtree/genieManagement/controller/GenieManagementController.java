package com.mindtree.genieManagement.controller;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import com.mindtree.genieManagement.dto.CampusMindDto;
import com.mindtree.genieManagement.dto.GenieDto;
import com.mindtree.genieManagement.exception.CampusMIDNotFoundException;
import com.mindtree.genieManagement.exception.ControllerException;
import com.mindtree.genieManagement.exception.GenieIDNotFoundException;
import com.mindtree.genieManagement.exception.ServiecException;
import com.mindtree.genieManagement.service.GenieManagementService;

@RestController
public class GenieManagementController {

	Map<String, Object> response = null;

	@Autowired
	private GenieManagementService service;

	@PostMapping("/insertCampus")
	public ResponseEntity<Map<String, Object>> insertCampus(@RequestBody CampusMindDto campusDto) {
		
		response = new HashMap<>();
		response.put("message", "Inserting details of the  campus Mind");
		response.put("body", service.insertCampus(campusDto));

		return new ResponseEntity<Map<String, Object>>(response, HttpStatus.CREATED);
	}

	@PostMapping("/insertGenie/{mid}")
	public ResponseEntity<Map<String, Object>> insertGenie(@RequestBody GenieDto genieDto, @PathVariable String mid)
			throws ControllerException {

		response = new HashMap<>();
		response.put("message", "Inserting details of the genie of particular campus Mind");
		response.put("body", service.insertGenie(genieDto, mid));

		return new ResponseEntity<Map<String, Object>>(response, HttpStatus.CREATED);
	}

	@GetMapping("/displayGenie/{status}")
	public ResponseEntity<Map<String, Object>> displayGenieDetails(@PathVariable("staus") boolean status)
			throws ControllerException {
		response = new HashMap<>();
		response.put("message", "Displaying details of the Genie with genie status");
		response.put("body", service.displayGenieDetails(status));
		return new ResponseEntity<Map<String, Object>>(response, HttpStatus.FOUND);
	}

	@GetMapping("/genieStatus/{id}/{status}")
	public ResponseEntity<Map<String, Object>> updateGenieStatus(@PathVariable("staus") boolean status,
			@PathVariable("id") int id) throws ControllerException {
		response = new HashMap<>();
		response.put("message", "Displaying details of the Genie with genie status");
		response.put("body", service.updateGenieStatus(status, id));
		return new ResponseEntity<Map<String, Object>>(response, HttpStatus.OK);

	}

//	@GetMapping("/genie/{id}")
//	public ResponseEntity<Map<String, Object>> getByID(@PathVariable String id) throws ControllerException {
//		response = new HashMap<>();
//		response.put("message", "Displaying details of the Genie with genie status");
//		response.put("status", HttpStatus.OK);
//		response.put("body", service.getByGenieId(Integer.parseInt(id)));
//
//		return new ResponseEntity<Map<String, Object>>(response, HttpStatus.FOUND);
//
//	}
}
