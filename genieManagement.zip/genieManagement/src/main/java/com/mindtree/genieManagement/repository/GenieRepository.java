package com.mindtree.genieManagement.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.mindtree.genieManagement.dto.GenieDto;
import com.mindtree.genieManagement.entity.Genie;

public interface GenieRepository extends JpaRepository<Genie, Integer> {

//	@Query(value="select * from genie where genie_status =:s", nativeQuery = true)
//	public List<Genie> findByStatus(@Param("s") String status);
	
	@Query("select g from Genie g where g.genieStatus=:n")
	public List<Genie> findByStatus(@Param("n") boolean status);

}
