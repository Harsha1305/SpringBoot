package com.mindtree.genieManagement.exception;

public class ServiecException extends ControllerException {

	public ServiecException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public ServiecException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		// TODO Auto-generated constructor stub
	}

	public ServiecException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public ServiecException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public ServiecException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

}
