package com.mindtree.genieManagement.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

public class GenieDto {

	private int id;
	private String genieDescription;
	private Boolean genieStatus;
	@JsonIgnoreProperties("genies")
	private CampusMindDto campusMind;

	public GenieDto() {
		super();
		// TODO Auto-generated constructor stub
	}

	public GenieDto(String genieDescription, Boolean genieStatus, CampusMindDto campusMind) {
		super();
		this.genieDescription = genieDescription;
		this.genieStatus = genieStatus;
		this.campusMind = campusMind;
	}

	public GenieDto(int id, String genieDescription, Boolean genieStatus, CampusMindDto campusMind) {
		super();
		this.id = id;
		this.genieDescription = genieDescription;
		this.genieStatus = genieStatus;
		this.campusMind = campusMind;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getGenieDescription() {
		return genieDescription;
	}

	public void setGenieDescription(String genieDescription) {
		this.genieDescription = genieDescription;
	}

	public Boolean getGenieStatus() {
		return genieStatus;
	}

	public void setGenieStatus(Boolean genieStatus) {
		this.genieStatus = genieStatus;
	}

	public CampusMindDto getCampusMind() {
		return campusMind;
	}

	public void setCampusMind(CampusMindDto campusMind) {
		this.campusMind = campusMind;
	}

}
