package com.mindtree.genieManagement.entity;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
public class CampusMind {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;
	private String mid;
	private String name;
	private String projectName;
	@OneToMany(mappedBy = "campusMind",cascade = CascadeType.REMOVE)
	private List<Genie> genie=new ArrayList<>() ;

	
	public CampusMind(String mid, String name, String projectName, List<Genie> genie) {
		super();
		this.mid = mid;
		this.name = name;
		this.projectName = projectName;
		this.genie = genie;
	}

	public CampusMind(int id, String mid, String name, String projectName, List<Genie> genie) {
		super();
		this.id = id;
		this.mid = mid;
		this.name = name;
		this.projectName = projectName;
		this.genie = genie;
	}

	public CampusMind() {
		super();
		// TODO Auto-generated constructor stub
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getMid() {
		return mid;
	}

	public void setMid(String mid) {
		this.mid = mid;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getProjectName() {
		return projectName;
	}

	public void setProjectName(String projectName) {
		this.projectName = projectName;
	}

	public List<Genie> getGenie() {
		return genie;
	}

	public void setGenie(List<Genie> genie) {
		this.genie = genie;
	}

}
