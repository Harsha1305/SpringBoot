package com.mindtree.genieManagement.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.mindtree.genieManagement.entity.CampusMind;

public interface CampusMindRepository extends JpaRepository<CampusMind, Integer>{

	public CampusMind findByMid(String mid);

}
